
public interface expensable {
	
	public double getCost();

}
