import java.util.ArrayList;

public class FirePlane extends FireVehicle {
	private double minHeight;


	public FirePlane (int ID, int waterAmount, double eventCost, double yearsExperience, double minHeight) throws MinHeighException {
		super(ID,waterAmount,eventCost,yearsExperience);
		if(minHeight<=50)
			this.minHeight=minHeight;
		else
			throw new MinHeighException("can't build a plane with min height that is bigger than 50");
	}

	//creates a team with one commander and one fire fighter
	public boolean createTeam( ArrayList <FireFighter> FireFighters) {
		addFighterToTeam(FireFighters);
		addCommanderToTeam(FireFighters);
		if( team.size() != 2 ) {                    //can't create a team
			for(int i=0;i<team.size();i++) {
				team.get(i).isOccupied=false;      //free the fighters
				team.remove(i);
			}	
			return false;
		}
		return true;
	}

	private void addCommanderToTeam(ArrayList<FireFighter> FireFighters) {
		for(int i=0;i<FireFighters.size() && team.size()==1;i++) {
			if( FireFighters.get(i).isCommander ) {
				this.addCommander((FireCommander)FireFighters.get(i));   //add one commander
				FireFighters.get(i).isOccupied=true;
			}
		}		
	}

	private void addFighterToTeam(ArrayList<FireFighter> FireFighters) {
		for(int i=0;i<FireFighters.size() && team.size() < 1;i++) {
			if(!FireFighters.get(i).isCommander) {  //add one FireFighter
				this.addFighter(FireFighters.get(i));
				FireFighters.get(i).isOccupied=true;
			}
		}		
	}

	


}