import java.util.ArrayList;

public abstract class FireVehicle implements Experiencable, expensable, Comparable<Comparable>{
	protected int ID;
	protected int waterAmount; 
	protected double eventCost;
	protected double yearsExperience;
	protected ArrayList <FireFighter> team = new ArrayList <FireFighter>();
	public boolean isOccupied;

	//constructor
	public FireVehicle(int ID, int waterAmount, double eventCost, double yearsExperience) {
		this.ID=ID;
		this.waterAmount=waterAmount;
		this.eventCost=eventCost;
		this.yearsExperience=yearsExperience;
	}

	public double getCost() {
		return eventCost;
	}

	public double getyearsExperience () {
		return yearsExperience;
	}

	public int getWaterAmount() {
		return waterAmount;
	}

	public void addFighter(FireFighter f) {
		team.add(f);
	}

	//add the commander as first in the list
	public void addCommander(FireCommander f) {
		team.add(0,f);
	}

	protected abstract boolean createTeam( ArrayList <FireFighter> FireFighters);

	//compare by water amount
	public int compareTo(Comparable other) {
		if (this.waterAmount > ((FireVehicle)other).getWaterAmount())
			return 1;
		if (this.waterAmount < ((FireVehicle)other).getWaterAmount())
			return -1;
		return 0;
	}

}