
public class FireFighter implements Experiencable , expensable , Comparable<Comparable>{

	protected String name;
	protected int ID;
	protected int age;
	protected double yearsExperience;
	protected int salary;
	public boolean isCommander, isVolenteer, isOccupied;

	//constructor
	public FireFighter(String name, int ID, int age, double yearsExperience) { 
		this.name=name;
		this.ID=ID;
		this.age=age;
		isCommander=false;
		this.yearsExperience=yearsExperience;
		salary+=1000;
	}

	//constructorVolenteer
	public FireFighter(String name, int ID, int age) {
		this(name,ID,age,0);
		salary-=1000;
		isVolenteer=true;
	}

	public double getyearsExperience () {
		return yearsExperience;
	}

	public double getCost() {
		return salary;
	}

	public int getAge() {
		return age;
	}

	public void addToSalary() {
		salary+=200;
	}

	public int getEventCost() {
		return 200;
	}

	//compare by experience
	public int compareTo(Comparable other) {
		if (this.yearsExperience > ((FireFighter)other).getyearsExperience())
			return 1;
		if (this.yearsExperience < ((FireFighter)other).getyearsExperience())
			return -1;
		return 0;
	}
}
