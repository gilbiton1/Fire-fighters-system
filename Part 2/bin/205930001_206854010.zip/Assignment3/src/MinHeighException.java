
public class MinHeighException extends Exception {
	
	public MinHeighException () {}
	public  MinHeighException (String s) {
		System.out.println(s);
		
	}
}

