
public class FireCommander extends FireFighter  {

	private int commandLevel;

	//constructor
	public FireCommander(String name, int ID, int age, double yearsExperience, int commandLevel) {
		super(name,ID,age,yearsExperience);
		if (yearsExperience>3) {
			isCommander=true;
			salary+=1000;
			this.commandLevel=commandLevel;		
		}
		else 
			throw new NotExperienced("too young to be a commander!");
	}

	public void addToSalary() {
		salary+=300;
	}

	public int getEventCost() {
		return 300;
	}

	public int getCommandLevel() {
		return commandLevel;
	}

	//compare by command level
	public int compareTo(FireCommander other) {
		if (this.commandLevel > other.getCommandLevel())
			return 1;
		if (this.commandLevel < other.getCommandLevel())
			return -1;
		return 0;
	}


}