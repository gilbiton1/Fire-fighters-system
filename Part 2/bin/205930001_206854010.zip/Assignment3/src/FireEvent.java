import java.util.ArrayList;

public class FireEvent implements Comparable <Comparable>{
	private int level,wantedWaterAmount,curWaterAmount;
	private String location;
	private ArrayList <FireFighter> teamFighters;
	private ArrayList <FireVehicle> teamVehicles;
	public boolean canBeHandle;
	public double totalExpense;

	//constructor
	public FireEvent(int level, String location) {
		this.level=level;
		this.location= location;
		wantedWaterAmount=0;
		curWaterAmount=0;
		teamFighters = new ArrayList <FireFighter>();
		teamVehicles = new ArrayList <FireVehicle>();
	}

	public void setLocation(String location) {
		this.location=location;
	}

	public void setLevel(int level) {
		this.level=level;
	}
	
	public void setWantedWaterAmount(int wantedWaterAmount) {
		this.wantedWaterAmount= wantedWaterAmount;
	}
	
	public int getWantedWaterAmount() {
		return wantedWaterAmount;
	} 
	public int getCurWaterAmount() {
		return curWaterAmount;
	}
	
	public int getLevel() {
		return level;
	}
	
	public ArrayList <FireFighter> getTeamFighters(){
		 return teamFighters;
	}
	
	public ArrayList <FireVehicle> getTeamVehicles(){
		 return teamVehicles;
	}
	
	public String getLocation() {
		return location.toString();
	}
	
	//return number of fighters in the event (without commanders)
	public int numOfFighters() {
		int counter=0;
		for(int i=0;i<teamVehicles.size();i++) {
			for(int j=0;j<teamVehicles.get(i).team.size();j++) {
				teamFighters.add(teamVehicles.get(i).team.get(j));			//add the fighters to team
				totalExpense+=teamVehicles.get(i).team.get(j).getEventCost(); //add cost to total expenses
				if(!teamVehicles.get(i).team.get(j).isCommander)
					counter++;
			}
		}
		return counter;
	}
	
	//compare events by level
	public int compareTo(Comparable other) {
		if (this.level > ((FireEvent)other).getLevel())
			return 1;
		if (this.level < ((FireEvent)other).getLevel())
			return -1;
		return 0;
	}

	public void addToCurWaterAmount(int curWaterAmount) {
		this.curWaterAmount+= curWaterAmount;
	}

	public void addVehicle(FireVehicle e) {
		totalExpense+=e.getCost();   //add event cost to total cost
		teamVehicles.add(e);
	}

}
