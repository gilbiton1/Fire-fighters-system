
public class NotExperienced extends RuntimeException {

	public NotExperienced () {}
	
	public NotExperienced (String s) {
		System.out.println(s);
	}

	
}
