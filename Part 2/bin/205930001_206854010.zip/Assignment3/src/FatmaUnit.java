import java.util.ArrayList;
import java.util.Comparator;

public class FatmaUnit {
	private ArrayList <FireFighter> FireFighters;
	private ArrayList<FireVehicle> FireTrucks;
	private ArrayList <FireVehicle> FirePlanes;;
	private ArrayList <FireEvent> FireEvents;
	private ArrayList <Comparable> availables;
	private int countPlanes;

	public FatmaUnit() {
		FireFighters = new ArrayList <FireFighter>();
		FireTrucks = new ArrayList <FireVehicle>();
		FirePlanes = new ArrayList <FireVehicle>();
		FireEvents = new ArrayList <FireEvent>();
		availables = new ArrayList <>();
	}

	//return if the event can be handle or not
	public boolean eventHandling (int level, String location) {
		FireEvent event=createNewEvent(level,location);
		if(level<=5) {
			getAllAvailableVehicles(FireTrucks);		//get all the available trucks 
			return lowerLevelEvent(event);
		}
		else {
			getAllAvailableVehicles(FirePlanes); 		//get all the available planes 
			return higherLevelEvent(event);
		}
	}

	private FireEvent createNewEvent(int level, String location) {
		FireEvent event = new FireEvent(level,location);
		event.setWantedWaterAmount(level*10000);
		FireEvents.add(event); 					//add the event to the list of events in the unit		
	return event;
	}

	//return if the event can be handle or not
	private boolean lowerLevelEvent(FireEvent event) {
		while(!enoughWater(event) && availables.size()!=0) {
			FireTruck max=(FireTruck)getMax(availables);  							//keep the truck with the max water amount
			if(max.createTeam(sortByMax(getAllAvailableFighters(FireFighters)))) {         //can create a team of available fighters
				matchToEvent(max,event);
			}
			else {
				freeTheFighters(event);
				return false;			  //didn't find a team of fireFighters
			}	
			if(enoughWater(event)) {
				payTheFighters(event);
				event.canBeHandle=true;
				return true;
			}
		}
		freeTheFighters(event);
		return false;     //there is no more available trucks and not enough water
	}

	//return if the event can be handle or not
	private boolean higherLevelEvent(FireEvent event) {
		countPlanes=0;
		while(countPlanes<2 && availables.size()!=0 ) {
			FirePlane max=(FirePlane)getMax(availables);
			if(max.createTeam(sortByMax(getAllAvailableFighters(FireFighters)))) {         //can create a team of available fighters
				matchToEvent(max,event);
				countPlanes++;	
			}
		}
		if (countPlanes==2) {					//have 2 planes, needs to find trucks
			getAllAvailableVehicles(FireTrucks);
			return lowerLevelEvent(event);
		}
		else{
			freeTheFighters(event);
			return false;				//there is no more available trucks and not enough water
		}
	}

	//match a vehicle to event
	private void matchToEvent(FireVehicle max, FireEvent event) {
		max.isOccupied=true;
		availables.remove(max);
		event.addVehicle(max);
		event.addToCurWaterAmount(max.getWaterAmount());		
	}

	//keeps all available vehicles in array
	private void getAllAvailableVehicles(ArrayList <FireVehicle> a) {
		availables= new ArrayList();
		for(int i=0;i<a.size();i++) {
			if(!a.get(i).isOccupied)
				availables.add(a.get(i));
		}
	}

	//keeps all available Fighters in array
	private ArrayList<FireFighter> getAllAvailableFighters(ArrayList <FireFighter> a) { 
		ArrayList<FireFighter> availableFighters= new ArrayList<>();
		for(int i=0;i<a.size();i++) {
			if(!a.get(i).isOccupied)
				availableFighters.add(a.get(i));
		}
		return availableFighters;
	}

	//pay the fighters for the event
	private void payTheFighters(FireEvent event) {
		for(int i=0;i<event.getTeamVehicles().size();i++) {     
			for(int j=0;j<event.getTeamVehicles().get(i).team.size();j++) {
				event.getTeamVehicles().get(i).team.get(j).addToSalary();
			}
		}
	}

	//set free fighters from an event 
	private void freeTheFighters(FireEvent event) {
		while(event.getTeamVehicles().size()!=0) {
			for(int i=0;i<event.getTeamVehicles().size();i++) {     
				event.getTeamVehicles().get(i).isOccupied=false;    //set the vehicles as available
				for(int j=0;j<event.getTeamVehicles().get(i).team.size();j++) {
					event.getTeamVehicles().get(i).team.get(j).isOccupied=false;  //set the fighters as available
				}
				event.getTeamVehicles().remove(i);
			}
		}
	}

	//return true if there is enough water for handling the event
	private boolean enoughWater(FireEvent event) {
		return (event.getCurWaterAmount() >= event.getWantedWaterAmount());
	}

	//return true and print the data if the event given was handled
	public boolean closeEvent (String location) {
		FireEvent event= findTheEvent(location);
		if(event.canBeHandle) {
			int num = event.numOfFighters() + event.getTeamVehicles().size(); 	//fighters+commanders
			double averageV = averageExperience(event.getTeamVehicles());
			double averageF = averageExperience(event.getTeamFighters());
			double cost=event.totalExpense;
			freeTheFighters(event);
			System.out.println("Fire event ended!" + "\n"
					+"location:" + event.getLocation() + "\n" 
					+ "level:" + event.getLevel() + "\n"
					+ "Number of fighters in the event:" + num + "\n"
					+ "Fire fighters average years of experience:" + averageF  + "\n"
					+ "Fire vehicles average years of experience:" + averageV + "\n"
					+ "Event cost:" + cost );
			return true;
		}
		return false;		//can't find the event or the event was not handled
	}

	//return the max from an arraylist
	public static Comparable getMax(ArrayList <? extends Comparable> Comparables) {
		Comparable max= Comparables.get(0); 
		for(int i=0;i<Comparables.size();i++) {
			if(Comparables.get(i).compareTo(max)>0)
				max=Comparables.get(i);
		}
		return max;
	}

	//creates new arrayList of fireFighters that is sorted by largest to smallest
	private static ArrayList<FireFighter> sortByMax(ArrayList<FireFighter> available){
		ArrayList <FireFighter> sort= new ArrayList<FireFighter>();
		int i=0;
		while(available.size()!=0) {
			FireFighter max=(FireFighter)(getMax(available));
			sort.add(i,max);
			available.remove(max);
			i++;
		}
		return sort;
	}

	//find an event on the list of events of the unit
	private FireEvent findTheEvent(String location) {
		for(int i=0; i< FireEvents.size(); i++) {
			if (FireEvents.get(i).getLocation().equals(location))
				return FireEvents.get(i);
		}
		return null;
	}

	//add FireFighter to the list of the available FireFighter
	public boolean addFighter(FireFighter f) { 
		return FireFighters.add(f);

	}

	//add commander to the list of the available commanders
	public boolean addCommander (FireCommander c) {
		return FireFighters.add(c);

	}

	//add FireTruck to the list of the available FireTruck
	public boolean addTruck (FireTruck t) {
		return FireTrucks.add(t);

	}

	//add FirePlane to the list of the available FirePlane
	public boolean addPlane (FirePlane p) {
		return FirePlanes.add(p);
		
	}


	//returns the average experience 
	public static double averageExperience( ArrayList<? extends Experiencable> experience ) {
		double sum = 0;
		for(int i=0;i<experience.size();i++) {
			sum += experience.get(i).getyearsExperience();
		}
		return sum/experience.size();
	}

	//returns total Expenses of the ArrayList
	public static double totalExpenses (ArrayList < ? extends expensable> expenses) {
		double sum = 0;
		for(int i=0;i<expenses.size();i++) {
			sum += expenses.get(i).getCost();
		}
		return sum;
	}

	//return average Age
	public double averageAge () {
		double sum = 0;
		for(int i=0;i<FireFighters.size();i++) {
			sum+=FireFighters.get(i).getAge();
		}
		return sum/FireFighters.size();
	}
}
