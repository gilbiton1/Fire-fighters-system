import java.util.ArrayList;

public class FireTruck extends FireVehicle {
	private int numFighters;


	//constructor
	public FireTruck(int ID, int waterAmount, double eventCost, double yearsExperience, int numFighters) {
		super(ID,waterAmount,eventCost,yearsExperience);
		this.numFighters = numFighters;
	}

	//creates a team with one commander and wanted number of fire fighter
	public boolean createTeam( ArrayList <FireFighter> FireFighters) {
		addFighterToTeam(FireFighters);
		addCommanderToTeam(FireFighters);
		if( team.size() != numFighters+1 ) {
			for(int i=0;i<team.size();i++) {
				team.get(i).isOccupied=false;
				team.remove(i);
			}	return false;
		}
		return true;

	}

	private void addCommanderToTeam(ArrayList<FireFighter> FireFighters) {
		for(int i=0;i<FireFighters.size();i++) {
			if(FireFighters.get(i).isCommander && team.size()==numFighters ) {   //if he is commander and we have enough fighters
				this.addCommander((FireCommander)FireFighters.get(i)); 
				FireFighters.get(i).isOccupied=true;
			}
		}		
	}

	private void addFighterToTeam(ArrayList<FireFighter> FireFighters) {
		for(int i=0;i<FireFighters.size();i++) {
			if(!FireFighters.get(i).isCommander && team.size()< numFighters) {
				this.addFighter(FireFighters.get(i));
				FireFighters.get(i).isOccupied=true;
			}
		}		
	}



}
