
public interface Experiencable {

	public double getyearsExperience();
}
